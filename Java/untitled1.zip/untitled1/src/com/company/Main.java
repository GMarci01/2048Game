package com.company;




import org.jline.terminal.Terminal;
import org.jline.terminal.TerminalBuilder;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Terminal terminal = TerminalBuilder.builder()
                .system(true)
                .build();

        System.out.println("Nyomj le bármilyen billentyűt (q = kilépés)");
        System.out.print(">>> ");

        int input;
        while ((input = terminal.reader().read()) != -1) {
            char ch = (char) input;

            if (input == 13) {
                System.out.println("\n[Enter lenyomva]");
            } else if (input == 27) {
                System.out.println("\n[ESC lenyomva]");
            } else if (input == 113) {
                System.out.println("\nKilépés...");
                break;
            } else {
                System.out.println("Lenyomtad: '" + ch + "' (kód: " + input + ")");
            }
            System.out.print(">>> ");
        }
        terminal.close();
    }
}